import React from 'react';

const Logo: React.FC<{ className?: string }> = ({ className }) => (
    <svg 
        className={className} 
        viewBox="0 0 200 200" 
        xmlns="http://www.w3.org/2000/svg" 
        preserveAspectRatio="xMidYMid meet"
        aria-label="Bihar Health Club Logo"
        fontFamily="Inter, sans-serif"
        fontWeight="700"
    >
        <defs>
            {/* Path for top text */}
            <path
              id="text-path-top"
              d="M 35,100 A 65 65, 0, 1, 1, 165, 100"
              fill="none"
            />
            {/* Path for bottom text */}
            <path
              id="text-path-bottom"
              d="M 160,103 A 60 60, 0, 1, 0, 40, 103"
              fill="none"
            />
        </defs>

        {/* Outer Ring */}
        <g>
            {/* Bottom green part */}
            <circle cx="100" cy="100" r="90" fill="#059669" />
            {/* Top blue part */}
            <path d="M 10,100 A 90 90 0 0 1 190,100" fill="#1e40af" stroke="#1e40af" strokeWidth="1" />
            
            {/* White side hearts */}
            <path d="M38 83 C 38 80, 41 80, 41 80 S 44 80, 44 83 C 44 86, 41 89, 41 89 S 38 86, 38 83 Z" fill="white" />
            <path d="M156 83 C 156 80, 159 80, 159 80 S 162 80, 162 83 C 162 86, 159 89, 159 89 S 156 86, 156 83 Z" fill="white" />
        </g>
        
        {/* Text on ring */}
        <text fill="white" fontSize="18" letterSpacing="2">
          <textPath href="#text-path-top" startOffset="50%" textAnchor="middle">
            BIHAR HEALTH
          </textPath>
        </text>
        <text fill="white" fontSize="18" fontWeight="700" letterSpacing="12">
          <textPath href="#text-path-bottom" startOffset="50%" textAnchor="middle">
            CLUB
          </textPath>
        </text>

        {/* Inner white circle */}
        <circle cx="100" cy="100" r="72" fill="white" />

        {/* Central Graphic */}
        <g transform="translate(0, 5)">
            {/* Cross */}
            <g fill="#1e40af">
                <path d="M 100 50 L 100 150" stroke="#1e40af" strokeWidth="4" strokeLinecap="round" />
                <path d="M 50 100 L 150 100" stroke="#1e40af" strokeWidth="4" strokeLinecap="round" />
                <circle cx="100" cy="48" r="4" />
                <circle cx="100" cy="152" r="4" />
                <circle cx="48" cy="100" r="4" />
                <circle cx="152" cy="100" r="4" />
            </g>

            {/* Stethoscope Heart */}
            <g strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" fill="none">
                {/* Green part */}
                <path
                  d="M 80 115 C 80 135, 100 145, 100 145 C 100 145, 120 135, 120 115"
                  stroke="#047857"
                />
                
                {/* Blue part */}
                <path
                  d="M 100 70 C 120 70, 130 90, 120 115"
                  stroke="#2563eb"
                />

                {/* Orange part */}
                <path
                  d="M 100 70 C 80 70, 70 90, 80 115"
                  stroke="#f97316"
                />
                
                 {/* Intertwined green part */}
                 <path d="M 80 115 C 90 105, 110 105, 120 115" stroke="#047857" strokeWidth="6" />
            </g>
            <circle cx="100" cy="67" r="5" fill="#1e40af" />
        </g>
    </svg>
);

export default Logo;