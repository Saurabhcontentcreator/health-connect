import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { ClockIcon, MapPinIcon, CloudIcon } from './IconComponents';

const WeatherWidget: React.FC = () => {
    const { user } = useAuth();
    const [time, setTime] = useState(new Date());
    const [locationInfo, setLocationInfo] = useState({
        name: 'Patna', // Default location
        temp: 32,
        isLoading: true,
        error: null as string | null,
    });

    useEffect(() => {
        const timerId = setInterval(() => setTime(new Date()), 1000);
        return () => clearInterval(timerId);
    }, []);

    useEffect(() => {
        if (!navigator.geolocation) {
            setLocationInfo(prev => ({ ...prev, isLoading: false, error: "Geolocation is not supported." }));
            return;
        }

        const success = async (position: GeolocationPosition) => {
            const { latitude, longitude } = position.coords;
            
            try {
                // Using Nominatim for reverse geocoding (no API key needed)
                const geoResponse = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`);
                if (!geoResponse.ok) throw new Error('Failed to fetch location name.');
                
                const data = await geoResponse.json();
                const cityName = data.address.city || data.address.town || data.address.village || 'Unknown Location';
                
                // NOTE: Weather data is mocked as no weather API key is provided.
                const mockTemp = 30 + Math.floor(Math.random() * 5); // Random temp between 30-34

                setLocationInfo({ name: cityName, temp: mockTemp, isLoading: false, error: null });
            } catch (error) {
                console.error("Error fetching location data:", error);
                setLocationInfo(prev => ({ ...prev, isLoading: false, error: "Could not fetch location." }));
            }
        };

        const error = (err: GeolocationPositionError) => {
            let errorMessage = "An unknown error occurred.";
            switch(err.code) {
                case err.PERMISSION_DENIED:
                    errorMessage = "Location access denied.";
                    break;
                case err.POSITION_UNAVAILABLE:
                    errorMessage = "Location unavailable.";
                    break;
                case err.TIMEOUT:
                    errorMessage = "Location request timed out.";
                    break;
            }
            setLocationInfo(prev => ({ ...prev, isLoading: false, error: errorMessage }));
        };

        navigator.geolocation.getCurrentPosition(success, error, { timeout: 10000 });

    }, []);
    
    const formattedTime = time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });

    const getGreeting = () => {
        const hour = new Date().getHours();
        if (hour < 12) return 'Good Morning';
        if (hour < 18) return 'Good Afternoon';
        return 'Good Evening';
    };

    const renderWeatherInfo = () => {
        if (locationInfo.isLoading) {
            return <span className="text-xs">Loading location...</span>;
        }
        
        return (
            <>
                <div className="flex items-center space-x-2">
                    <MapPinIcon className="w-5 h-5" />
                    <span className="font-semibold hidden sm:inline" title={locationInfo.error ?? undefined}>
                      {locationInfo.error ? locationInfo.error : locationInfo.name}
                    </span>
                </div>
                <div className="flex items-center space-x-2">
                    <CloudIcon className="w-5 h-5" />
                    <span className="font-semibold bg-blue-600 px-2 py-0.5 rounded-md">{locationInfo.temp}°C</span>
                </div>
            </>
        );
    }

    return (
        <div className="bg-teal-900 text-white text-sm z-20 shadow-inner">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center h-10">
                <div className="flex items-center space-x-2">
                    {user && <span className="font-semibold">{getGreeting()}, {user.firstName}</span>}
                </div>
                <div className="flex items-center space-x-4 md:space-x-6">
                    {renderWeatherInfo()}
                    <div className="flex items-center space-x-2">
                        <ClockIcon className="w-5 h-5" />
                        <span className="font-mono tracking-wider">{formattedTime}</span>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default WeatherWidget;