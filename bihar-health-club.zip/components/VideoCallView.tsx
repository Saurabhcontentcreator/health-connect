import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { MicIcon, MicOffIcon, VideoIcon, VideoOffIcon, PhoneOffIcon } from './IconComponents';

interface VideoCallViewProps {
  onEndCall: () => void;
}

const VideoCallView: React.FC<VideoCallViewProps> = ({ onEndCall }) => {
  const { user } = useAuth();
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [isMicMuted, setIsMicMuted] = useState(false);
  const [isCameraOff, setIsCameraOff] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    let stream: MediaStream | null = null;
    const startMedia = async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        setLocalStream(stream);
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }
        // Simulate remote stream by using the same local stream
        if (remoteVideoRef.current) {
          remoteVideoRef.current.srcObject = stream;
        }
      } catch (err) {
        console.error("Error accessing media devices.", err);
        setError("Could not access camera and microphone. Please check permissions and try again.");
      }
    };

    startMedia();

    return () => {
      // Cleanup: stop all tracks when the component unmounts
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const toggleMic = () => {
    if (localStream) {
      localStream.getAudioTracks().forEach(track => {
        track.enabled = !track.enabled;
      });
      setIsMicMuted(!isMicMuted);
    }
  };

  const toggleCamera = () => {
    if (localStream) {
      localStream.getVideoTracks().forEach(track => {
        track.enabled = !track.enabled;
      });
      setIsCameraOff(!isCameraOff);
    }
  };

  const handleEndCall = () => {
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
    }
    onEndCall();
  };

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-[calc(100vh-10rem)] bg-red-50 border border-red-200 rounded-lg p-8">
        <h2 className="text-2xl font-bold text-red-700 mb-4">Permission Denied</h2>
        <p className="text-red-600 text-center max-w-md mb-6">{error}</p>
        <button
          onClick={handleEndCall}
          className="px-6 py-2 bg-red-600 text-white font-semibold rounded-lg hover:bg-red-700 transition-colors"
        >
          Go Back
        </button>
      </div>
    );
  }

  return (
    <div className="relative w-full h-[calc(100vh-10rem)] bg-gray-900 rounded-2xl overflow-hidden shadow-2xl flex flex-col">
      {/* Remote Video */}
      <div className="relative flex-grow bg-black">
        <video ref={remoteVideoRef} autoPlay playsInline className="w-full h-full object-cover" muted />
        <div className="absolute bottom-4 left-4 bg-black bg-opacity-50 text-white px-3 py-1 rounded-lg text-sm">
            Dr. Ramesh Kumar (Remote)
        </div>
      </div>
      
      {/* Local Video Preview */}
      <div className="absolute top-6 right-6 w-48 h-32 md:w-64 md:h-48 bg-gray-800 rounded-lg overflow-hidden shadow-lg border-2 border-gray-700 transition-all duration-300">
        <video ref={localVideoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
         <div className="absolute bottom-2 left-2 bg-black bg-opacity-50 text-white px-2 py-0.5 rounded-md text-xs">
            {user?.firstName} (You)
        </div>
      </div>

      {/* Call Controls */}
      <div className="absolute bottom-0 left-0 right-0 p-4 bg-black bg-opacity-30 backdrop-blur-sm">
        <div className="flex justify-center items-center space-x-4">
          <button
            onClick={toggleMic}
            className={`p-3 rounded-full transition-colors ${isMicMuted ? 'bg-red-600 text-white' : 'bg-gray-700 bg-opacity-50 text-white hover:bg-gray-600'}`}
            aria-label={isMicMuted ? 'Unmute Microphone' : 'Mute Microphone'}
          >
            {isMicMuted ? <MicOffIcon className="h-6 w-6" /> : <MicIcon className="h-6 w-6" />}
          </button>
          
          <button
            onClick={toggleCamera}
            className={`p-3 rounded-full transition-colors ${isCameraOff ? 'bg-red-600 text-white' : 'bg-gray-700 bg-opacity-50 text-white hover:bg-gray-600'}`}
            aria-label={isCameraOff ? 'Turn Camera On' : 'Turn Camera Off'}
          >
            {isCameraOff ? <VideoOffIcon className="h-6 w-6" /> : <VideoIcon className="h-6 w-6" />}
          </button>
          
          <button
            onClick={handleEndCall}
            className="p-3 px-6 bg-red-600 text-white rounded-full transition-colors hover:bg-red-700 flex items-center space-x-2"
            aria-label="End Call"
          >
            <PhoneOffIcon className="h-6 w-6" />
            <span className="font-semibold">End Call</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default VideoCallView;
