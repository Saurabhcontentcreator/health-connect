import React, { useState } from 'react';
import { MedicineIn } from '../types';
import * as db from '../services/dbService';
import { PillIcon } from './IconComponents';

interface AddMedicineFormProps {
    onSuccess: () => void;
    onClose: () => void;
}

const AddMedicineForm: React.FC<AddMedicineFormProps> = ({ onSuccess, onClose }) => {
    const [name, setName] = useState('');
    const [mrp, setMrp] = useState('');
    const [price, setPrice] = useState('');
    const [description, setDescription] = useState('');
    const [imageUrl, setImageUrl] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (!name || !mrp || !price || !description) {
            setError('All fields except Image URL are required.');
            return;
        }
        if (isNaN(Number(mrp)) || isNaN(Number(price))) {
            setError('MRP and Price must be valid numbers.');
            return;
        }

        setIsLoading(true);

        try {
            const newMedicineData: MedicineIn = {
                name,
                mrp: Number(mrp),
                price: Number(price),
                description,
                imageUrl: imageUrl || `https://placehold.co/300x200/e0f2fe/0891b2?text=${encodeURIComponent(name)}`,
            };
            db.addMedicine(newMedicineData);
            setIsLoading(false);
            onSuccess();
        } catch (err: any) {
            setError(err.message || 'Failed to add medicine.');
            setIsLoading(false);
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-2xl p-8 w-full max-w-lg transform transition-all">
                <div className="flex items-center mb-6">
                    <PillIcon className="h-6 w-6 text-teal-600" />
                    <h2 className="ml-3 text-2xl font-bold text-gray-800">Add New Medicine</h2>
                </div>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label htmlFor="med-name" className="block text-sm font-medium text-gray-700">Medicine Name</label>
                        <input
                            type="text"
                            id="med-name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm"
                            placeholder="e.g., Paracetamol 500mg"
                            required
                        />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="med-mrp" className="block text-sm font-medium text-gray-700">MRP (₹)</label>
                            <input
                                type="number"
                                id="med-mrp"
                                value={mrp}
                                onChange={(e) => setMrp(e.target.value)}
                                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm"
                                placeholder="e.g., 30.00"
                                required
                            />
                        </div>
                        <div>
                            <label htmlFor="med-price" className="block text-sm font-medium text-gray-700">Selling Price (₹)</label>
                            <input
                                type="number"
                                id="med-price"
                                value={price}
                                onChange={(e) => setPrice(e.target.value)}
                                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm"
                                placeholder="e.g., 25.50"
                                required
                            />
                        </div>
                    </div>
                    <div>
                        <label htmlFor="med-desc" className="block text-sm font-medium text-gray-700">Description</label>
                        <textarea
                            id="med-desc"
                            value={description}
                            onChange={(e) => setDescription(e.target.value)}
                            rows={3}
                            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm"
                            placeholder="e.g., For fever and pain relief. 10 tablets."
                            required
                        />
                    </div>
                     <div>
                        <label htmlFor="med-image" className="block text-sm font-medium text-gray-700">Image URL (Optional)</label>
                        <input
                            type="text"
                            id="med-image"
                            value={imageUrl}
                            onChange={(e) => setImageUrl(e.target.value)}
                            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm"
                            placeholder="https://example.com/image.png"
                        />
                    </div>

                    {error && <p className="text-red-500 text-sm text-center">{error}</p>}

                    <div className="flex justify-end space-x-4 pt-4 border-t border-gray-200 mt-6">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 transition-colors">
                            Cancel
                        </button>
                        <button type="submit" disabled={isLoading} className="px-4 py-2 bg-teal-600 text-white rounded-md hover:bg-teal-700 transition-colors disabled:bg-teal-400 disabled:cursor-not-allowed">
                            {isLoading ? 'Adding...' : 'Add Medicine'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AddMedicineForm;
