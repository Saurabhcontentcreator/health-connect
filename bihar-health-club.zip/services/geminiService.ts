
import { GoogleGenAI, Type } from "@google/genai";

const recommendationSchema = {
  type: Type.OBJECT,
  properties: {
    specialty: {
      type: Type.STRING,
      description: "The recommended medical specialty, e.g., 'Cardiologist', 'General Physician', 'Dermatologist'.",
    },
    reasoning: {
      type: Type.STRING,
      description: "A brief, one-sentence explanation for the recommendation.",
    },
  },
  required: ['specialty', 'reasoning']
};

export const recommendDoctorSpecialty = async (symptoms: string): Promise<{ specialty: string; reasoning: string }> => {
  const API_KEY = process.env.API_KEY;

  if (!API_KEY) {
    console.warn("API_KEY environment variable not set. Using fallback recommendation logic.");
    // Fallback logic if API key is not present
    if (symptoms.toLowerCase().includes("fever") || symptoms.toLowerCase().includes("cough")) {
        return { specialty: "General Physician", reasoning: "Based on common symptoms like fever and cough." };
    } else if (symptoms.toLowerCase().includes("tooth") || symptoms.toLowerCase().includes("gum")) {
        return { specialty: "Dentist", reasoning: "Based on dental-related symptoms." };
    } else {
        return { specialty: "General Physician", reasoning: "For general or unspecified symptoms, a General Physician is a good starting point." };
    }
  }

  try {
    // Initialize the AI client only when the key is available
    const ai = new GoogleGenAI({ apiKey: API_KEY });
    
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Based on the following symptoms, what is the most likely medical specialty a person should consult? Symptoms: "${symptoms}"`,
      config: {
        responseMimeType: "application/json",
        responseSchema: recommendationSchema,
        temperature: 0.2,
      },
    });

    const jsonText = response.text.trim();
    const result = JSON.parse(jsonText);
    return result;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to get AI recommendation. Please try again.");
  }
};