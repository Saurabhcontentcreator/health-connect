


import React, { useState, useEffect, useCallback } from 'react';
import Header from './components/Header';
import DoctorCard from './components/DoctorCard';
import BookingModal from './components/BookingModal';
import AiRecommender from './components/AiRecommender';
import LoginPage from './components/LoginPage';
import AdminDashboard from './components/AdminDashboard';
import OwnerDashboard from './components/OwnerDashboard';
import VideoCallView from './components/VideoCallView';
import PharmacyView from './components/PharmacyView';
import LabTestsView from './components/LabTestsView';
import { useAuth } from './contexts/AuthContext';
import * as db from './services/dbService';
import { User, Doctor, Appointment, AppointmentIn, PharmaCompany, UserSession, Medicine, MedicineOrder, Address, LabTest, LabTestBooking, LabTestBookingIn } from './types';
import { SearchIcon, StethoscopeIcon } from './components/IconComponents';

const App: React.FC = () => {
  const { isAuthenticated, user, authLogs } = useAuth();
  const [currentView, setCurrentView] = useState<'search' | 'dashboard' | 'videoCall' | 'ownerDashboard' | 'pharmacy' | 'labTests'>('search');
  
  const [users, setUsers] = useState<User[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [pharmaCompanies, setPharmaCompanies] = useState<PharmaCompany[]>([]);
  const [sessions, setSessions] = useState<UserSession[]>([]);
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [medicineOrders, setMedicineOrders] = useState<MedicineOrder[]>([]);
  const [allMedicineOrders, setAllMedicineOrders] = useState<MedicineOrder[]>([]);
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [labTests, setLabTests] = useState<LabTest[]>([]);
  const [labTestBookings, setLabTestBookings] = useState<LabTestBooking[]>([]);
  const [allLabTestBookings, setAllLabTestBookings] = useState<LabTestBooking[]>([]);
  
  const [location, setLocation] = useState('');
  const [specialty, setSpecialty] = useState('');
  const [filteredDoctors, setFilteredDoctors] = useState<Doctor[]>([]);
  const [bookingDoctor, setBookingDoctor] = useState<Doctor | null>(null);
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);

  const refreshData = useCallback(() => {
    const allUsers = db.getUsers();
    const allDoctors = db.getDoctors();
    const allAppointments = db.getAllAppointments();
    const allPharmaCompanies = db.getPharmaCompanies();
    const allSessions = db.getAllSessions();
    const allMedicines = db.getMedicines();
    const allOrders = db.getAllMedicineOrders();
    const allLabTests = db.getLabTests();
    const allBookings = db.getAllLabTestBookings();
    
    setUsers(allUsers);
    setDoctors(allDoctors);
    setFilteredDoctors(allDoctors); // Initially show all doctors
    setAppointments(allAppointments);
    setPharmaCompanies(allPharmaCompanies);
    setSessions(allSessions);
    setMedicines(allMedicines);
    setAllMedicineOrders(allOrders);
    setLabTests(allLabTests);
    setAllLabTestBookings(allBookings);
    
    if (user) {
        setMedicineOrders(db.getMedicineOrdersForUser(user.id));
        setAddresses(db.getAddressesForUser(user.id));
        setLabTestBookings(db.getLabTestBookingsForUser(user.id));
    }

  }, [user]);
  
  useEffect(() => {
    if (isAuthenticated && user) {
      refreshData();
      
      const validViewsForRole: Record<User['role'], string[]> = {
          patient: ['search', 'videoCall', 'pharmacy', 'labTests'],
          admin: ['search', 'dashboard', 'videoCall', 'pharmacy', 'labTests'],
          owner: ['search', 'ownerDashboard', 'videoCall', 'pharmacy', 'labTests']
      };
      
      const defaultViewForRole: Record<User['role'], 'search' | 'dashboard' | 'ownerDashboard'> = {
          patient: 'search',
          admin: 'dashboard',
          owner: 'ownerDashboard'
      };
      
      if(!validViewsForRole[user.role].includes(currentView)){
          setCurrentView(defaultViewForRole[user.role]);
      }
    }
  }, [isAuthenticated, user, currentView, refreshData]);

  const handleSearch = () => {
    const results = db.getDoctors(location, specialty);
    setFilteredDoctors(results);
  };

  const handleAiRecommendation = (recommendedSpecialty: string) => {
    setSpecialty(recommendedSpecialty);
    const results = db.getDoctors(location, recommendedSpecialty);
    setFilteredDoctors(results);
  };

  const handleBookAppointment = useCallback(async (data: AppointmentIn) => {
    await db.bookAppointment(data);
    refreshData();
    // Keep the modal open for the success message to show
  }, [refreshData]);

  const handleSelectSlot = (doctor: Doctor, slot: string) => {
    setBookingDoctor(doctor);
    setSelectedSlot(slot);
  };
  
  const clearFilters = () => {
      setLocation('');
      setSpecialty('');
      setFilteredDoctors(doctors);
  };

  const handlePlaceOrder = useCallback((userId: number, cart: { [medicineId: number]: number }, address: Address, deliveryFee: number, promiseFee: number): { message: string } => {
    const result = db.placeMedicineOrder(userId, cart, address, deliveryFee, promiseFee);
    refreshData();
    return result;
  }, [refreshData]);

  const handleBookLabTest = useCallback((data: LabTestBookingIn): { message: string } => {
    const result = db.bookLabTest(data);
    refreshData();
    return result;
  }, [refreshData]);
  
  const handleEndCall = () => {
      if (!user) return;
      const defaultView = user.role === 'owner' ? 'ownerDashboard' : (user.role === 'admin' ? 'dashboard' : 'search');
      setCurrentView(defaultView);
  }

  const renderView = () => {
    if (currentView === 'labTests' && user) {
        return <LabTestsView tests={labTests} bookings={labTestBookings} user={user} addresses={addresses} onBookTest={handleBookLabTest} onDataRefresh={refreshData} />;
    }
    if (currentView === 'pharmacy' && user) {
        return <PharmacyView medicines={medicines} orders={medicineOrders} addresses={addresses} onPlaceOrder={handlePlaceOrder} user={user} onDataRefresh={refreshData} />;
    }
    if (currentView === 'videoCall') {
        return <VideoCallView onEndCall={handleEndCall} />;
    }
    
    if (user?.role === 'owner') {
      switch(currentView) {
        case 'ownerDashboard':
            return <OwnerDashboard users={users} doctors={doctors} appointments={appointments} authLogs={authLogs} pharmaCompanies={pharmaCompanies} sessions={sessions} medicineOrders={allMedicineOrders} />;
        case 'search':
        default:
          // Owners can also search, so fall through to the search view
          break;
      }
    }

    if (user?.role === 'admin') {
      switch(currentView) {
        case 'dashboard':
          return <AdminDashboard 
                    doctors={doctors} 
                    appointments={appointments} 
                    authLogs={authLogs} 
                    pharmaCompanies={pharmaCompanies} 
                    sessions={sessions}
                    allMedicineOrders={allMedicineOrders}
                    medicines={medicines}
                    allLabTestBookings={allLabTestBookings}
                    refreshData={refreshData}
                 />;
        case 'search':
        default:
          // Admins can also search, so fall through to the search view
          break;
      }
    }
    
    return (
      <div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
            <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-lg">
                <h2 className="text-2xl font-bold text-gray-800 mb-4">Find Your Doctor</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                        <label htmlFor="location" className="block text-sm font-medium text-gray-700">Location</label>
                        <input type="text" id="location" value={location} onChange={e => setLocation(e.target.value)} placeholder="e.g., Patna" className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500" />
                    </div>
                    <div>
                        <label htmlFor="specialty" className="block text-sm font-medium text-gray-700">Specialty</label>
                        <input type="text" id="specialty" value={specialty} onChange={e => setSpecialty(e.target.value)} placeholder="e.g., Dentist" className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500" />
                    </div>
                </div>
                <div className="flex items-center space-x-4">
                    <button onClick={handleSearch} className="flex-1 inline-flex items-center justify-center px-4 py-2.5 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-teal-600 hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500">
                       <SearchIcon className="w-5 h-5 mr-2" /> Search
                    </button>
                     <button onClick={clearFilters} className="flex-1 inline-flex items-center justify-center px-4 py-2.5 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        Clear Filters
                    </button>
                </div>
            </div>
            <div className="lg:col-span-1">
                <AiRecommender onRecommendation={handleAiRecommendation} />
            </div>
        </div>

        {filteredDoctors.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredDoctors.map(doctor => (
              <DoctorCard key={doctor.id} doctor={doctor} onBook={handleSelectSlot} />
            ))}
          </div>
        ) : (
            <div className="text-center py-16 px-4 bg-white rounded-xl shadow-lg">
                <StethoscopeIcon className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-lg font-medium text-gray-900">No Doctors Found</h3>
                <p className="mt-1 text-sm text-gray-500">
                    Try adjusting your search filters or use the AI recommender to find a specialty.
                </p>
            </div>
        )}
      </div>
    );
  };

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header currentView={currentView} setCurrentView={setCurrentView} />

      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderView()}
      </main>

      {bookingDoctor && selectedSlot && (
        <BookingModal
          doctor={bookingDoctor}
          selectedSlot={selectedSlot}
          onClose={() => {
            setBookingDoctor(null);
            setSelectedSlot(null);
          }}
          onBook={handleBookAppointment}
        />
      )}
    </div>
  );
};

export default App;